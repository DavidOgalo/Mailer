<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Ajax Contact Form</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <script src='https://www.google.com/recaptcha/api.js'></script>
</head>
<body>

    <!-- ajax contact form -->
    <section style="margin-top: 50px;">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card">
                        <h5 class="card-header">Ajax Contact Form</h5>
                        <div class="card-body">
                            <form class="contact__form" method="post" action="SendMail.php">
                                
                                <!-- form message -->
                                <div class="row">
                                    <div class="col-12">
                                        <div class="contact__msg" style="display: none">
                                            <p>Your message was sent successfully.</p>
                                        </div>
                                    </div>
                                </div>
                                <!-- end message -->

                                <!-- form element -->
                                <div class="row">
                                    <div class="col-md-6 form-group">
                                        <input name="name" type="text" class="form-control" placeholder="Name" required>
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <input name="email" type="email" class="form-control" placeholder="Email" required>
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <input name="phone" type="text" class="form-control" placeholder="Phone" required>
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <input name="subject" type="text" class="form-control" placeholder="Subject" required>
                                    </div>
                                    <div class="col-12 form-group">
                                        <textarea name="message" class="form-control" rows="3" placeholder="Message" required></textarea>
                                    </div>
                                    <div class="col-12 form-group">
                                        <div class="g-recaptcha" data-sitekey="6LescPEUAAAAAJhGugUQyhcJEqg97d4qRT4ubuRO"></div>
                                    </div>
                                    <div class="col-12">
                                        <input name="submit" type="submit" class="btn btn-success" value="Send Message">
                                    </div>
                                </div>
                                <!-- end form element -->
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script src="main.js"></script>
</body>
</html>